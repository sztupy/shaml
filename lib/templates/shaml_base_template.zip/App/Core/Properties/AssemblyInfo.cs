﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WebBase")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("WebBase.Core")]
