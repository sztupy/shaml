create table Users ("pId" varchar(255) not null, Username varchar(255), Email varchar(255), Comment varchar(255), primary key ("pId"))
