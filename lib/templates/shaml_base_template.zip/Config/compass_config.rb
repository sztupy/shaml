# Require any additional compass plugins here.
project_type = :stand_alone
css_dir = "Public/Content"
sass_dir = "App/Stylesheets"
images_dir = "Public/Content/Images"
output_style = :compact
# To enable relative image paths using the images_url() function:
# http_images_path = :relative
http_images_path = "/Public/Content/Images"
